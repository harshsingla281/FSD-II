export default function Dashboard() {
  return (
    <div>
      <h2>Dashboard Component</h2>
      <p>This component is loaded lazily.</p>
    </div>
  );
}
